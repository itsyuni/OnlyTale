<?php
namespace app\forms;

use std, gui, framework, app;


class game2rus3 extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
