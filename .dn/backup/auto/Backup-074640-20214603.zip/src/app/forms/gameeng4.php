<?php
namespace app\forms;

use std, gui, framework, app;


class gameeng4 extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
