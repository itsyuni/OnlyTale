<?php
namespace app\forms;

use std, gui, framework, app;


class youwinrus extends AbstractForm
{

}