<?php
namespace app\forms;

use std, gui, framework, app;


class gamerus2 extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
